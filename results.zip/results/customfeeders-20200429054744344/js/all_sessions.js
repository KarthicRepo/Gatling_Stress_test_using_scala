allUsersData = {
    
color: '#FF9D00',
name: 'Active Users',
data: [
  [1588139267000,1],[1588139268000,1],[1588139269000,1],[1588139270000,1],[1588139271000,1],[1588139272000,1]
],
tooltip: { yDecimals: 0, ySuffix: '', valueDecimals: 0 }
    , zIndex: 20
    , yAxis: 1
};