allUsersData = {
    
color: '#FF9D00',
name: 'Active Users',
data: [
  [1588143317000,1],[1588143318000,1],[1588143319000,1],[1588143320000,1],[1588143321000,1],[1588143322000,1]
],
tooltip: { yDecimals: 0, ySuffix: '', valueDecimals: 0 }
    , zIndex: 20
    , yAxis: 1
};